/*
 * rtwtypes.h
 *
 * Code generation for function 'TransitiveKNN_part2'
 *
 * C source code generated on: Mon Jan 05 13:12:27 2015
 *
 */

#ifndef __RTWTYPES_H__
#define __RTWTYPES_H__
#include "tmwtypes.h"
/* 
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE (1U)
#endif 
#ifndef FALSE
#define FALSE (0U)
#endif 
#endif
/* End of code generation (rtwtypes.h) */
